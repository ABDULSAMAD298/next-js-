interface feedbacks {
  content: string;
  author: string;
  role: string;
}

const feedbacks: feedbacks[] = [
  {
    content:
      'Builderkit takes care of everything from authentication to payments, get your production-ready app within hours.',
    author: 'FIRST-1',
    role: 'Founder',
  },
  {
    content:
      'Builderkit takes care of everything from authentication to payments, get your production-ready app within hours.',
    author: 'FIRST-2',
    role: 'Founder',
  },
  {
    content:
      'Builderkit takes care of everything from authentication to payments, get your production-ready app within hours.',
    author: 'Samuel Jack',
    role: 'Founder',
  },
  {
    content:
      'Builderkit takes care of everything from authentication to payments, get your production-ready app within hours.',
    author: 'Samuel Jack',
    role: 'Founder',
  },
  {
    content:
      'Builderkit takes care of everything from authentication to payments, get your production-ready app within hours.',
    author: 'Samuel Jack',
    role: 'Founder',
  },
  {
    content:
      'Builderkit takes care of everything from authentication to payments, get your production-ready app within hours.',
    author: 'Samuel Jack',
    role: 'Founder',
  },
  {
    content:
      'Builderkit takes care of everything from authentication to payments, get your production-ready app within hours.',
    author: 'Samuel Jack',
    role: 'Founder',
  },
  {
    content:
      'Builderkit takes care of everything from authentication to payments, get your production-ready app within hours.',
    author: 'Samuel Jack',
    role: 'Founder',
  },
  {
    content:
      'Builderkit takes care of everything from authentication to payments, get your production-ready app within hours.',
    author: 'Samuel Jack',
    role: 'Founder',
  },
  {
    content:
      'Builderkit takes care of everything from authentication to payments, get your production-ready app within hours.',
    author: 'Samuel Jack',
    role: 'Founder',
  },
  {
    content:
      'Builderkit takes care of everything from authentication to payments, get your production-ready app within hours.',
    author: 'Samuel Jack',
    role: 'Founder',
  },
  {
    content:
      'Builderkit takes care of everything from authentication to payments, get your production-ready app within hours.',
    author: 'Samuel Jack',
    role: 'Founder',
  },
  {
    content:
      'Builderkit takes care of everything from authentication to payments, get your production-ready app within hours.',
    author: 'Samuel Jack',
    role: 'Founder',
  },
  {
    content:
      'Builderkit takes care of everything from authentication to payments, get your production-ready app within hours.',
    author: 'Samuel Jack',
    role: 'Founder',
  },
  {
    content:
      'Builderkit takes care of everything from authentication to payments, get your production-ready app within hours.',
    author: 'LAST-1',
    role: 'Founder',
  },
  {
    content:
      'Builderkit takes care of everything from authentication to payments, get your production-ready app within hours.',
    author: 'LAST-2',
    role: 'Founder',
  },
];
export default feedbacks;
