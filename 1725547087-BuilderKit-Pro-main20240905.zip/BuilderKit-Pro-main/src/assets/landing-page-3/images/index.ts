import hero from './hero.svg';
import features from './features.svg';

export { hero, features };
