import Notion from './Notion.svg';
import Grammarly from './Grammarly.svg';
import Intercom from './Intercom.svg';
import Unsplash from './Unsplash.svg';
import Descript from './Descript.svg';
import howTo from './howTo.svg';
import Toggle from './Toggle.svg';
import Discount from './Discount.svg';
export { Notion, Grammarly, Intercom, Unsplash, Descript, howTo, Toggle, Discount };
